# CHANGELOG - Módulo Registro de Ventas
## GridRetail

**Última actualización:** 2026-01-27

---

## [Pendiente]

### Validaciones
- [ ] _Agregar issues aquí cuando se detecten_

### UX/UI
- [ ] _Agregar issues aquí cuando se detecten_

### Lógica de Negocio
- [ ] _Agregar issues aquí cuando se detecten_

---

## [2026-01-XX] v1.1 (Próxima versión)

_Cambios pendientes de implementar_

---

## [2026-01-24] v1.0 - Versión Inicial

### Funcionalidades Implementadas
- ✅ Formulario de registro de venta (Boca de Urna)
- ✅ Soporte para 16 tipos de venta
- ✅ Campos condicionales según tipo de venta:
  - IMEI/ICCID para ventas con equipo
  - Operador cedente para portabilidades
  - Número a portar para portabilidades
  - Plan tarifario para postpago
- ✅ Selector de tienda filtrado por usuario
- ✅ Validación de permisos por rol
- ✅ Integración con tabla `ventas`

### Tipos de Venta Soportados
```
POSTPAGO: OSS_BASE, OSS_CAPTURA, OPP_MONO, OPP_CAPTURA, OPP_BASE, 
          VR_MONO, VR_CAPTURA, VR_BASE, MISS_IN
PACK:     PACK_VR, PACK_OSS, PACK_VR_BASE
RENO:     RENO
PREPAGO:  PREPAGO, PORTA_PP
OTROS:    ACCESORIOS
```

### Dependencias
- Tabla `usuarios` (usuario actual)
- Tabla `tiendas` (selector de tienda)
- Tabla `tipos_venta` (catálogo)
- Tabla `operadores_cedentes` (para portabilidades)
- Tabla `ventas` (destino de datos)

---

## Convenciones de este archivo

### Estados de items pendientes
- `[ ]` Pendiente
- `[~]` En progreso
- `[x]` Completado (mover a sección de versión)

### Categorías
- **Validaciones**: Reglas de validación de campos
- **UX/UI**: Cambios visuales, mensajes, flujo de usuario
- **Lógica de Negocio**: Reglas que afectan cálculos o datos
- **Fix**: Corrección de errores

### Prioridades (usar en descripción)
- 🔴 Alta - Bloquea uso normal
- 🟡 Media - Afecta experiencia pero hay workaround
- 🟢 Baja - Mejora nice-to-have
